export default function Header() {
    return(
        <div className='p-2 bg-cyan-500'>
            <h1 className="font-sans text-neutral-800 text-3xl text-center">Task Manager</h1>
        </div>
    )
}